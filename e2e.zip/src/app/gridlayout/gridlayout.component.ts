import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gridlayout',
  templateUrl: './gridlayout.component.html',
  styleUrls: ['./gridlayout.component.css']
})
export class GridlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
