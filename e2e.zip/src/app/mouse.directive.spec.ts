import { MouseDirective } from './mouse.directive';

describe('MouseDirective', () => {
  it('should create an instance', () => {
    const directive = new MouseDirective();
    expect(directive).toBeTruthy();
  });
});
