import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exist',
  templateUrl: './exist.component.html',
  styleUrls: ['./exist.component.css']
})
export class ExistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
